package top.jimxu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import top.jimxu.entity.User;

public interface UserMapper extends BaseMapper<User>{
}
